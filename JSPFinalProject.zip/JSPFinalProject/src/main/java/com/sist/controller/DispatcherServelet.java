package com.sist.controller;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

//DispatcherServelet : 스프링에서 제공하는 컨트롤러 => 동작 -> 구분(어노테이션), 등록(xml)

/*
 	MVC 동작 과정
 	1. 요청 => DispatcherServlet을 찾는다
 			 ------------------- url 주소로 찾는다 -> .do(list.do, insert.do... => 무조건 DispatcherServlet을 찾는다)
 */
@WebServlet("*.do")
public class DispatcherServelet extends HttpServlet {
	private static final long serialVersionUID = 1L;


	public void init(ServletConfig config) throws ServletException {
		
	}


	protected void service(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
	}

}
